"""Duration parsing."""

def parse_duration(text: str) -> float:
    """Parse a duration string and return the total number of seconds as a float.

    Accepts two forms: (1) a plain non-negative integer (optionally surrounded by
    whitespace) representing seconds; (2) one or more components of the form
    <non-negative integer><unit> where unit is one of 'd', 'h', 'm', 's', 'ms'.
    Components must appear in descending unit order (d > h > m > s > ms), each
    unit at most once. Whitespace is allowed around the entire string and
    between components, but not between a number and its unit. The function
    computes the sum: days*86400 + hours*3600 + minutes*60 + seconds +
    milliseconds/1000. Returns the result as a float.
    """
    if not isinstance(text, str):
        raise TypeError('duration must be a string')
    stripped = text.strip()
    if not stripped:
        raise ValueError('empty duration string')
    if stripped.isdigit():
        return float(stripped)
    total = 0.0
    i = 0
    n = len(stripped)
    unit_info = {'d': (0, 86400.0), 'h': (1, 3600.0), 'm': (2, 60.0), 's': (3, 1.0), 'ms': (4, 0.001)}
    last_order = -1
    used_units = set()
    while i < n:
        if stripped[i].isspace():
            i += 1
            continue
        if not stripped[i].isdigit():
            raise ValueError(f'expected number at position {i} in {text!r}')
        start = i
        while i < n and stripped[i].isdigit():
            i += 1
        num_str = stripped[start:i]
        num = int(num_str)
        if i >= n:
            raise ValueError(f'missing unit after number {num_str} in {text!r}')
        if stripped[i:i + 2] == 'ms':
            unit = 'ms'
            i += 2
        elif stripped[i] in unit_info:
            unit = stripped[i]
            i += 1
        else:
            raise ValueError(f"unknown unit '{stripped[i]}' in {text!r}")
        order, multiplier = unit_info[unit]
        if order <= last_order:
            raise ValueError(f'units out of order in {text!r}')
        if unit in used_units:
            raise ValueError(f"duplicate unit '{unit}' in {text!r}")
        used_units.add(unit)
        last_order = order
        total += num / multiplier
    if not used_units:
        raise ValueError(f'no valid components in {text!r}')
    return total
