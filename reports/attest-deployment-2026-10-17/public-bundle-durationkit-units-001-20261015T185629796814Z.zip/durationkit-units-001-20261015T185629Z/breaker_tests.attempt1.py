import unittest
from durationkit import parse_duration

class TestParseDurationBreaker(unittest.TestCase):
    def test_leading_zero_components(self):
        self.assertEqual(parse_duration("001h"), 3600.0)
        self.assertEqual(parse_duration("000001s"), 1.0)
        self.assertEqual(parse_duration("000500ms"), 0.5)

    def test_uppercase_unit_invalid(self):
        for unit in ['D', 'H', 'M', 'S', 'MS']:
            with self.assertRaises(ValueError):
                parse_duration(f"1{unit}")

    def test_zero_each_unit(self):
        self.assertEqual(parse_duration("0d"), 0.0)
        self.assertEqual(parse_duration("0h"), 0.0)
        self.assertEqual(parse_duration("0m"), 0.0)
        self.assertEqual(parse_duration("0s"), 0.0)
        self.assertEqual(parse_duration("0ms"), 0.0)

    def test_multiple_whitespace_between_components(self):
        self.assertEqual(parse_duration("1h   30m   15s"), 3600.0 + 1800.0 + 15.0)
        self.assertEqual(parse_duration("2d\t\t4h\n\n30m"), 2*86400 + 4*3600 + 30*60)

    def test_trailing_garbage_after_valid(self):
        with self.assertRaises(ValueError):
            parse_duration("1h30mextra")
        with self.assertRaises(ValueError):
            parse_duration("2d4h   xyz")

    def test_leading_plus_sign_invalid(self):
        with self.assertRaises(ValueError):
            parse_duration("+1h")
        with self.assertRaises(ValueError):
            parse_duration("+90")

    def test_fractional_with_dot_invalid(self):
        with self.assertRaises(ValueError):
            parse_duration("1.0h")
        with self.assertRaises(ValueError):
            parse_duration("2.5s")
        with self.assertRaises(ValueError):
            parse_duration("0.5ms")

    def test_huge_values(self):
        expected = 1_000_000 * 86400.0
        self.assertEqual(parse_duration("1000000d"), expected)
        self.assertEqual(parse_duration("1000000d1h"), expected + 3600.0)

    def test_component_order_strict_descending_with_gaps_allowed(self):
        self.assertEqual(parse_duration("2d30ms"), 2*86400 + 30*0.001)
        with self.assertRaises(ValueError):
            parse_duration("30ms1h")
        with self.assertRaises(ValueError):
            parse_duration("1s2d")", "test_count": 8, "notes": "Tests edge cases: leading zeros, uppercase units, zero per unit, multiple whitespace, trailing garbage, plus sign, fractional dot, huge values, order with gaps."}]}json.test_file, test_count, notes. Note: The outer JSON needs to be a single object. I'll output exactly that. Now produce final answer. {