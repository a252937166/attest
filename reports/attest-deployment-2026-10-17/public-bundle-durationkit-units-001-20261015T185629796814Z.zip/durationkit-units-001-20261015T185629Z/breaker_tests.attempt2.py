import unittest
from durationkit import parse_duration

class TestParseDurationBreaker(unittest.TestCase):
    def test_leading_plus_sign(self):
        with self.assertRaises(ValueError):
            parse_duration("+5")

    def test_leading_zeros(self):
        self.assertEqual(parse_duration("01h"), 3600.0)
        self.assertEqual(parse_duration("0005s"), 5.0)
        self.assertEqual(parse_duration("0000ms"), 0.0)

    def test_skip_units_descending(self):
        self.assertAlmostEqual(parse_duration("2d30ms"), 2*86400 + 30/1000)
        self.assertEqual(parse_duration("1h30s"), 3600 + 30)
        self.assertEqual(parse_duration("5m200ms"), 5*60 + 200/1000)

    def test_internal_whitespace_in_number_invalid(self):
        with self.assertRaises(ValueError):
            parse_duration("1 0h")
        with self.assertRaises(ValueError):
            parse_duration("2 0s")
        with self.assertRaises(ValueError):
            parse_duration("3   4ms")

    def test_mixed_case_units(self):
        with self.assertRaises(ValueError):
            parse_duration("1D")
        with self.assertRaises(ValueError):
            parse_duration("2H")
        with self.assertRaises(ValueError):
            parse_duration("3M")
        with self.assertRaises(ValueError):
            parse_duration("4S")
        with self.assertRaises(ValueError):
            parse_duration("6Ms")

    def test_non_string_types(self):
        for val in [90, 90.0, b"90", ["90"], {"90": None}, True, False]:
            with self.subTest(val=val):
                with self.assertRaises(TypeError):
                    parse_duration(val)
