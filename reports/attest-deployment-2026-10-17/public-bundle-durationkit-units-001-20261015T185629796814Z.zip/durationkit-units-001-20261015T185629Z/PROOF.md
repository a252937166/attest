# Attest Proof Bundle: Accept unit suffixes in parse_duration

**Verdict: VERIFIED**  
Run `durationkit-units-001-20261015T185629Z` · profile `judge-demo` · provider `nebius_tokenfactory` · executor `tf_sandboxes`  
Started 2026-10-15T18:56:29.904029+00:00, finished 2026-10-15T19:00:29.936716+00:00.

Reasons: all gates passed


## 1. Frozen task
Task `durationkit-units-001`, spec digest `45a1d3c6649d17efe5edb6811ac83aeaf454275e0ff26eb809c1cae95971eae8`; base image `python:3.12-slim` (uuid `4fa16c8f-62a9-35a4-a4ea-07b7e8cd44ae`), checkpoint `92c106c2-e3bf-4d28-998e-0ad8538ef8dd`; test runner `unittest`; install: `none` (checkpoint networking off).

Users want to write durations such as '1h30m' instead of counting seconds. Extend parse_duration(text) so that, in addition to the existing plain-integer-seconds form, it accepts one or more components made of a non-negative integer followed by a unit: d (days), h (hours), m (minutes), s (seconds) or ms (milliseconds). Components must appear in descending unit order (for example '2d4h', '1h30m', '45m10s', '1s500ms'), each unit may appear at most once, and whitespace is allowed around the whole string and between components (but not between a number and its unit). The function keeps returning the total number of seconds as a float (so '500ms' is 0.5 and '1h30m' is 5400.0). Reject with ValueError: empty or whitespace-only input, negative numbers, fractional numbers, unknown units, repeated units, components out of descending order, a unit without a number, and any other malformed text. Keep raising TypeError for non-string input. The existing tests in tests/ must keep passing and must not be modified.

## 2. Specification and contract
Feasible: True. Extend parse_duration to accept duration strings composed of one or more components, each a non-negative integer followed by a unit (d, h, m, s, ms) in strictly descending order, with optional whitespace around the whole string and between components. The function returns the total seconds as a float. It must preserve existing behavior for plain integer strings, reject malformed inputs with ValueError, and reject non-string inputs with TypeError.

| Name | Signature | Behavior | Errors |
| --- | --- | --- | --- |
| parse_duration | parse_duration(text: str) -> float | Parses a duration string and returns the total number of seconds as a float. Accepts two forms: (1) a plain non-negative integer (optionally surrounded by white | TypeError: if text is not a string.; ValueError: if text is empty or whitespace-only after stripping.; ValueError: if any component contains a negative number ( |

Acceptance criteria:
1. parse_duration('90') == 90.0 and surrounding whitespace is still ignored (existing behavior preserved).
2. parse_duration('0') == 0.0 and parse_duration('0s') == 0.0.
3. Single components work for every unit: '2d' -> 172800.0, '3h' -> 10800.0, '15m' -> 900.0, '45s' -> 45.0, '500ms' -> 0.5.
4. Combined components in descending order work: '1h30m' -> 5400.0, '2d4h' -> 187200.0, '1m1s' -> 61.0, '1s500ms' -> 1.5, '1d1h1m1s1ms' -> 90061.001.
5. Whitespace is accepted around the string and between components: ' 1h 30m ' -> 5400.0; '1 h' raises ValueError.
6. ValueError for: '', '   ', '-1h', '1.5h', '1x', '1h1h', '30m1h', 'h', '1h30', 'abc'.
7. TypeError for non-string input such as 90 or None.
8. The return type is float for every accepted input.

## 3. Sealed tests (written before implementation by an independent model instance)
`sealed/test_sealed.py` sha256 `0a01dab6a42cea161f8dc3d8de933743548cc816eb8eaaa69bcba1fdec0e93dd`, 27 test methods, sealed at 2026-10-15T18:57:15.513221+00:00 by `nvidia/nemotron-3-super-120b-a12b`; attempts: 1.

Red check on the unmodified checkpoint (one child process per test under the supervisor): FAILED (12 of 27 methods: ERROR 12): 12 of 27 methods failing, 15 passing; operation `01a140ec-e1a3-746b-a6f6-fb49e8a914a5`.

| Sealed test method | Base (red) | Candidate |
| --- | --- | --- |
| test_sealed.TestParseDurationSealed.test_five_components | ERROR (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_four_components | ERROR (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_plain_integer | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_plain_integer_whitespace | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_return_type_float | ERROR (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_single_day | ERROR (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_single_hour | ERROR (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_single_millisecond | ERROR (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_single_minute | ERROR (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_single_second | ERROR (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_three_components | ERROR (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_two_components | ERROR (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_type_error_non_string_int | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_type_error_none | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_value_error_duplicate_unit | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_value_error_empty | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_value_error_fractional | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_value_error_missing_number | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_value_error_negative | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_value_error_number_without_unit | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_value_error_other_malformed | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_value_error_unknown_unit | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_value_error_whitespace_only | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_value_error_wrong_order | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_whitespace_around_and_between | ERROR (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_whitespace_between_number_and_unit_invalid | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_zero_and_zero_s | ERROR (1 ev) | ok (1 ev) |

## 4. Candidate patch
1 changed path(s); scope check passed; 8 implementer turn(s).

```diff
--- a/durationkit/parse.py
+++ b/durationkit/parse.py
@@ -2,14 +2,76 @@
 
 
 def parse_duration(text: str) -> float:
-    """Parse a duration string and return the number of seconds as a float.
+    """Parse a duration string and return the total number of seconds as a float.
 
-    Only a plain non-negative integer number of seconds is accepted at the
-    moment, for example ``"90"``. Surrounding whitespace is ignored.
+    Accepts two forms: (1) a plain non-negative integer (optionally surrounded by
+    whitespace) representing seconds; (2) one or more components of the form
+    <non-negative integer><unit> where unit is one of 'd', 'h', 'm', 's', 'ms'.
+    Components must appear in descending unit order (d > h > m > s > ms), each
+    unit at most once. Whitespace is allowed around the entire string and
+    between components, but not between a number and its unit. The function
+    computes the sum: days*86400 + hours*3600 + minutes*60 + seconds +
+    milliseconds/1000. Returns the result as a float.
     """
     if not isinstance(text, str):
         raise TypeError("duration must be a string")
     stripped = text.strip()
-    if not stripped.isdigit():
-        raise ValueError(f"unsupported duration: {text!r}")
-    return float(stripped)
+    if not stripped:
+        raise ValueError("empty duration string")
+    # If it's just a plain integer (digits only), treat as seconds.
+    if stripped.isdigit():
+        return float(stripped)
+    # Otherwise parse as sequence of components.
+    total = 0.0
+    i = 0
+    n = len(stripped)
+    # Unit info: order and multiplier.
+    unit_info = {
+        'd': (0, 86400.0),
+        'h': (1, 3600.0),
+        'm': (2, 60.0),
+        's': (3, 1.0),
+        'ms': (4, 0.001),
+    }
+    last_order = -1
+    used_units = set()
+    while i < n:
+        # Skip whitespace between components.
+        if stripped[i].isspace():
+            i += 1
+            continue
+        # Parse number.
+        if not stripped[i].isdigit():
+            raise ValueError(f"expected number at position {i} in {text!r}")
+        start = i
+        while i < n and stripped[i].isdigit():
+            i += 1
+        num_str = stripped[start:i]
+        # Disallow empty number (shouldn't happen due to check).
+        num = int(num_str)
+        # Parse unit.
+        if i >= n:
+            raise ValueError(f"missing unit after number {num_str} in {text!r}")
+        # Check for 'ms' first (two letters).
+        if stripped[i:i+2] == 'ms':
+            unit = 'ms'
+            i += 2
+        elif stripped[i] in unit_info:
+            unit = stripped[i]
+            i += 1
+        else:
+            raise ValueError(f"unknown unit '{stripped[i]}' in {text!r}")
+        # Validate unit order and uniqueness.
+        order, multiplier = unit_info[unit]
+        if order <= last_order:
+            raise ValueError(f"units out of order in {text!r}")
+        if unit in used_units:
+            raise ValueError(f"duplicate unit '{unit}' in {text!r}")
+        used_units.add(unit)
+        last_order = order
+        # Add to total.
+        total += num * multiplier
+        # After a component, loop continues (will skip whitespace).
+    if not used_units:
+        raise ValueError(f"no valid components in {text!r}")
+    return total
```

## 5. Fresh-branch verification (bound to the sealed suite)
Existing suite: OK (6 passed of 6). Sealed suite: OK (27 of 27 methods, each in its own process). Operation `01a140ed-c5e3-7182-86c5-7bab93b066b4`, networking disabled, disposable branch from the checkpoint.

| Binding check | Result |
| --- | --- |
| result_file_present | pass |
| supervisor_completed | pass |
| verifier_isolation_active | pass |
| nonce_matches | pass |
| sealed_file_unchanged_before | pass |
| sealed_file_unchanged_after | pass |
| no_discovery_error | pass |
| expected_test_ids_present | pass |
| no_unexpected_test_ids | pass |
| static_ids_match_red | pass |
| no_nonzero_exit | pass |
| no_signal | pass |
| no_timeout | pass |
| no_missing_or_forged_result | pass |
| all_expected_pass | pass |

Held-out suite: none configured.

## 6. Gates
| Gate | Result | Detail |
| --- | --- | --- |
| existing_suite | pass | OK |
| sealed_binding | pass | all checks pass |
| mutation | pass | score 0.75 on 12 mutants |
| adversarial_tests | pass | OK (6 of 6 methods, each in its own process) |
| drift_audit | pass | score 0.0 (aligned) |

## 7. Breaker pass
Mutants of changed lines, each in its own branch: 12 generated, 12 evaluated: 9 killed, 3 survived, 0 unknown; mutation score 0.750 (threshold 0.5).

| Mutant | File | Line | Mutation | Status | Killed by | Operation |
| --- | --- | --- | --- | --- | --- | --- |
| m01-13d929cc86 | durationkit/parse.py | 19 | remove `not` | killed | test_sealed.TestParseDurationSealed.test_plain_integer, test_sealed.TestParseDurationSealed.test_plain_integer_whitespac | 01a140ed-e37b-7646-a2f8-af8b42b91aa9 |
| m02-975a9a3188 | durationkit/parse.py | 26 | 0 -> 1 | killed | test_sealed.TestParseDurationSealed.test_zero_and_zero_s, test_sealed.TestParseDurationSealed.test_single_day, test_seal | 01a140ed-e349-70c0-9aeb-aba8d3c841db |
| m03-00da1e94c6 | durationkit/parse.py | 32 | 2 -> 3 | killed | test_sealed.TestParseDurationSealed.test_two_components, test_sealed.TestParseDurationSealed.test_four_components, test_ | 01a140ed-e3a0-7181-b959-284ff432e837 |
| m04-45219ead75 | durationkit/parse.py | 36 | 1 -> 2 | survived |  | 01a140ed-e446-7615-8ae8-8733f20a6373 |
| m05-3e512dfc98 | durationkit/parse.py | 41 | 1 -> 2 | killed | test_sealed.TestParseDurationSealed.test_whitespace_around_and_between | 01a140ed-e36f-777c-923b-3b1e2b1bdcc8 |
| m06-4a3a0e33aa | durationkit/parse.py | 47 | Lt -> LtE | killed | test_sealed.TestParseDurationSealed.test_value_error_number_without_unit | 01a140ed-e3ed-720a-9c19-106d8a21d5e2 |
| m07-f4f5dfa5fd | durationkit/parse.py | 53 | GtE -> Gt | killed | test_sealed.TestParseDurationSealed.test_value_error_number_without_unit | 01a140ed-e34b-7219-92aa-9d340f5528b5 |
| m08-3182ca6ba6 | durationkit/parse.py | 56 | 2 -> 3 | survived |  | 01a140ed-e3c2-7769-a34d-8bbddd407a6e |
| m09-c919a59444 | durationkit/parse.py | 58 | 2 -> 3 | survived |  | 01a140ed-ffcb-711b-8131-85ae2ce043d4 |
| m10-df8af4a18a | durationkit/parse.py | 63 | raise -> pass | killed | test_sealed.TestParseDurationSealed.test_whitespace_between_number_and_unit_invalid, test_sealed.TestParseDurationSealed | 01a140ed-ff41-7601-aed3-63647775941d |
| m11-e42d966392 | durationkit/parse.py | 67 | raise -> pass | killed | test_sealed.TestParseDurationSealed.test_value_error_wrong_order | 01a140ed-ffcd-7364-b1ff-172172deb3c3 |
| m12-6daa83b78a | durationkit/parse.py | 73 | Mult -> Div | killed | test_sealed.TestParseDurationSealed.test_single_day, test_sealed.TestParseDurationSealed.test_single_hour, test_sealed.T | 01a140ee-003d-76ff-9593-9152820af5a5 |

Model-written adversarial tests (`breaker_tests.py`, by `nvidia/nemotron-3-super-120b-a12b`, sha256 `f248079089a32bcc9703d6beda6da82c597f37f72db977a0e3f0ef6ac9856ea5`): OK (6 of 6 methods, each in its own process); binding ok; operation `01a140ef-b026-70ef-b75f-bc3ceeda5690`. Notes: Targeted edge cases: leading plus sign, leading zeros, skipped units, internal whitespace in number, mixed case units, non-string types.

(none)

## 8. Drift audit
Score 0.000 (aligned; threshold 0.6). The diff implements all required parsing rules for multi-component duration strings, preserves the existing plain-integer behavior, and passes all existing and acceptance tests. No scope deviations or unsupported claims are observed.

Scope narrowed: none  
Scope widened: none  
Unsupported claims: none

## 8b. Arbitration of generated-test failures
Not run (the verdict was not a generated-test NEEDS HUMAN, or arbitration was disabled).





## 9. Grounding
No grounding calls (specification named no external references).



## 10. Ledger
| Model | Role | Stage | Effort | In | Out | Cached | USD | Elapsed | Status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| nebius_tokenfactory:nvidia/Nemotron-3-Ultra-550b-a55b | spec | spec | default | 2727 | 1431 | 0 | 0.007020 | 5.6s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | seal | seal-1 | default | 2823 | 6786 | 0 | 0.006954 | 28.6s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | implement | implement-1 | default | 1779 | 88 | 0 | 0.000613 | 1.3s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | implement | implement-2 | default | 1916 | 89 | 0 | 0.000655 | 1.4s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | implement | implement-3 | default | 2117 | 1065 | 0 | 0.001594 | 5.8s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | implement | implement-4 | default | 2320 | 4941 | 0 | 0.005143 | 23.7s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | implement | implement-5 | default | 2497 | 83 | 0 | 0.000824 | 1.2s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | implement | implement-6 | default | 3326 | 711 | 0 | 0.001638 | 4.7s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | implement | implement-7 | default | 3268 | 946 | 0 | 0.001832 | 4.7s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | implement | implement-8 | default | 4112 | 199 | 0 | 0.001413 | 2.0s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | break | break-tests-1 | default | 2463 | 6386 | 0 | 0.006486 | 31.5s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | break | break-tests-2 | default | 2523 | 13736 | 0 | 0.013119 | 71.2s | ok |
| nebius_tokenfactory:nvidia/Nemotron-3-Ultra-550b-a55b | audit | drift-audit | default | 2901 | 2984 | 0 | 0.011853 | 14.4s | ok |

Model calls: 13 (0 failed, 0 malformed); tokens in/out/cached 34772/39445/0; USD: 0.059144.

| Sandbox op | Operation | Status | Exit | Duration | Image | Net | raw cost diag (not USD) |
| --- | --- | --- | --- | --- | --- | --- | --- |
| checkpoint | 01a140ec-4f90-734f-9014-f175e6e33146 | SUCCESS | 0 | 0.788s | retained | off | 0.00275393 |
| red-1 | 01a140ec-e1a3-746b-a6f6-fb49e8a914a5 | SUCCESS | 0 | 5.431s | disposable | off | 0.046223200000000006 |
| impl-tests-6 | 01a140ed-93e7-7601-8e14-867fe037d863 | SUCCESS | 0 | 0.751s | disposable | off | 0.0027468600000000003 |
| impl-python-7 | 01a140ed-b139-714f-8e66-0e53b3522118 | SUCCESS | 0 | 0.567s | disposable | off | 0.00113148 |
| verify | 01a140ed-c5e3-7182-86c5-7bab93b066b4 | SUCCESS | 0 | 5.543s | disposable | off | 0.04770473 |
| mutant-m01-13d929cc86 | 01a140ed-e37b-7646-a2f8-af8b42b91aa9 | SUCCESS | 0 | 5.524s | disposable | off | 0.0462271 |
| mutant-m02-975a9a3188 | 01a140ed-e349-70c0-9aeb-aba8d3c841db | SUCCESS | 0 | 5.42s | disposable | off | 0.04631578 |
| mutant-m03-00da1e94c6 | 01a140ed-e3a0-7181-b959-284ff432e837 | SUCCESS | 0 | 5.541s | disposable | off | 0.04647912 |
| mutant-m04-45219ead75 | 01a140ed-e446-7615-8ae8-8733f20a6373 | SUCCESS | 0 | 5.521s | disposable | off | 0.046563299999999995 |
| mutant-m05-3e512dfc98 | 01a140ed-e36f-777c-923b-3b1e2b1bdcc8 | SUCCESS | 0 | 5.524s | disposable | off | 0.04650196 |
| mutant-m06-4a3a0e33aa | 01a140ed-e3ed-720a-9c19-106d8a21d5e2 | SUCCESS | 0 | 5.489s | disposable | off | 0.04601801 |
| mutant-m07-f4f5dfa5fd | 01a140ed-e34b-7219-92aa-9d340f5528b5 | SUCCESS | 0 | 5.355s | disposable | off | 0.045751400000000005 |
| mutant-m08-3182ca6ba6 | 01a140ed-e3c2-7769-a34d-8bbddd407a6e | SUCCESS | 0 | 5.519s | disposable | off | 0.046516009999999997 |
| mutant-m09-c919a59444 | 01a140ed-ffcb-711b-8131-85ae2ce043d4 | SUCCESS | 0 | 5.422s | disposable | off | 0.04616993 |
| mutant-m10-df8af4a18a | 01a140ed-ff41-7601-aed3-63647775941d | SUCCESS | 0 | 5.411s | disposable | off | 0.04620391 |
| mutant-m11-e42d966392 | 01a140ed-ffcd-7364-b1ff-172172deb3c3 | SUCCESS | 0 | 5.421s | disposable | off | 0.046388660000000005 |
| mutant-m12-6daa83b78a | 01a140ee-003d-76ff-9593-9152820af5a5 | SUCCESS | 0 | 5.42s | disposable | off | 0.04638588 |
| breaker-tests | 01a140ef-b026-70ef-b75f-bc3ceeda5690 | SUCCESS | 0 | 1.734s | disposable | off | 0.011890099999999999 |

Sandbox operations: 18, total guest duration 80.381s, retained images ['92c106c2-e3bf-4d28-998e-0ad8538ef8dd'].

## 11. Limitations of this bundle
- Profile 'judge-demo': inference provider nebius_tokenfactory; submission runs must use NVIDIA Nemotron on Nebius Token Factory and are labeled separately.
- Sealed and adversarial suites run one child process per test under a supervisor that never imports candidate code; a candidate can still tamper from inside a child after the nonce was read (the mutation gate and held-out tests are the structural detectors).
- Model-written sealed and adversarial tests can be wrong; their failures block VERIFIED. An independent arbiter then classifies each failure (implementation bug, test defect or contract dispute) and, for pure test defects, corrects and re-verifies them (must pass on the candidate and still fail on the base). Arbitration is advisory by default and never clears an implementation bug or a contract dispute; it changes the verdict only in explicit apply mode.
- Grounding runs only when the specification names external references; sources are cited, not verified for correctness.
- Sandbox CPU/RAM quota controls were not found in the current public REST API; per operation only max_layer_bytes, a timeout and the networking flag are set.
- Sandbox raw 'cost' diagnostics are not USD; Codex gateway usage is ChatGPT allowance, not a Nebius charge; Nebius USD is computed from the public price table, not an invoice.
- Each run retains one checkpoint image on the service; no image-delete control was found in the current public REST API.
