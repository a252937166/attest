import unittest
from durationkit import parse_duration

class TestParseDurationSealed(unittest.TestCase):
    def test_plain_integer(self):
        self.assertEqual(parse_duration('90'), 90.0)

    def test_plain_integer_whitespace(self):
        self.assertEqual(parse_duration('  42 '), 42.0)

    def test_zero_and_zero_s(self):
        self.assertEqual(parse_duration('0'), 0.0)
        self.assertEqual(parse_duration('0s'), 0.0)

    def test_single_day(self):
        self.assertEqual(parse_duration('2d'), 172800.0)

    def test_single_hour(self):
        self.assertEqual(parse_duration('3h'), 10800.0)

    def test_single_minute(self):
        self.assertEqual(parse_duration('15m'), 900.0)

    def test_single_second(self):
        self.assertEqual(parse_duration('45s'), 45.0)

    def test_single_millisecond(self):
        self.assertEqual(parse_duration('500ms'), 0.5)

    def test_two_components(self):
        self.assertAlmostEqual(parse_duration('1h30m'), 5400.0)
        self.assertAlmostEqual(parse_duration('2d4h'), 187200.0)
        self.assertAlmostEqual(parse_duration('1m1s'), 61.0)
        self.assertAlmostEqual(parse_duration('1s500ms'), 1.5)

    def test_three_components(self):
        self.assertAlmostEqual(parse_duration('1d1h1m'), 90060.0)

    def test_four_components(self):
        self.assertAlmostEqual(parse_duration('1d1h1m1s'), 90061.0)

    def test_five_components(self):
        self.assertAlmostEqual(parse_duration('1d1h1m1s1ms'), 90061.001)

    def test_whitespace_around_and_between(self):
        self.assertAlmostEqual(parse_duration(' 1h 30m '), 5400.0)

    def test_whitespace_between_number_and_unit_invalid(self):
        with self.assertRaises(ValueError):
            parse_duration('1 h')

    def test_value_error_empty(self):
        with self.assertRaises(ValueError):
            parse_duration('')

    def test_value_error_whitespace_only(self):
        with self.assertRaises(ValueError):
            parse_duration('   ')

    def test_value_error_negative(self):
        with self.assertRaises(ValueError):
            parse_duration('-1h')

    def test_value_error_fractional(self):
        with self.assertRaises(ValueError):
            parse_duration('1.5h')

    def test_value_error_unknown_unit(self):
        with self.assertRaises(ValueError):
            parse_duration('1x')

    def test_value_error_duplicate_unit(self):
        with self.assertRaises(ValueError):
            parse_duration('1h1h')

    def test_value_error_wrong_order(self):
        with self.assertRaises(ValueError):
            parse_duration('30m1h')

    def test_value_error_missing_number(self):
        with self.assertRaises(ValueError):
            parse_duration('h')

    def test_value_error_number_without_unit(self):
        with self.assertRaises(ValueError):
            parse_duration('1h30')

    def test_value_error_other_malformed(self):
        with self.assertRaises(ValueError):
            parse_duration('abc')

    def test_type_error_non_string_int(self):
        with self.assertRaises(TypeError):
            parse_duration(90)

    def test_type_error_none(self):
        with self.assertRaises(TypeError):
            parse_duration(None)

    def test_return_type_float(self):
        self.assertIsInstance(parse_duration('90'), float)
        self.assertIsInstance(parse_duration('0s'), float)
        self.assertIsInstance(parse_duration('2d'), float)
        self.assertIsInstance(parse_duration('1h30m'), float)
        self.assertIsInstance(parse_duration('1d1h1m1s1ms'), float)
