# Attest Proof Bundle: Accept unit suffixes in parse_duration

**Verdict: NEEDS HUMAN**  
Run `durationkit-units-001-20261015T161057Z` · profile `judge-demo` · provider `nebius_tokenfactory` · executor `tf_sandboxes`  
Started 2026-10-15T16:10:57.811533+00:00, finished 2026-10-15T16:13:53.709288+00:00.

Reasons: implementer did not finish within 14 turns; child process nonzero exit: test_number_without_unit_in_multi_component_raises exit 1
Warnings: drift audit: score 0.00, widened 0, unsupported claims 1

## 1. Frozen task
Task `durationkit-units-001`, spec digest `45a1d3c6649d17efe5edb6811ac83aeaf454275e0ff26eb809c1cae95971eae8`; base image `python:3.12-slim` (uuid `4fa16c8f-62a9-35a4-a4ea-07b7e8cd44ae`), checkpoint `8fe2cd71-f45a-475a-bbea-53544d076ff4`; test runner `unittest`; install: `none` (checkpoint networking off).

Users want to write durations such as '1h30m' instead of counting seconds. Extend parse_duration(text) so that, in addition to the existing plain-integer-seconds form, it accepts one or more components made of a non-negative integer followed by a unit: d (days), h (hours), m (minutes), s (seconds) or ms (milliseconds). Components must appear in descending unit order (for example '2d4h', '1h30m', '45m10s', '1s500ms'), each unit may appear at most once, and whitespace is allowed around the whole string and between components (but not between a number and its unit). The function keeps returning the total number of seconds as a float (so '500ms' is 0.5 and '1h30m' is 5400.0). Reject with ValueError: empty or whitespace-only input, negative numbers, fractional numbers, unknown units, repeated units, components out of descending order, a unit without a number, and any other malformed text. Keep raising TypeError for non-string input. The existing tests in tests/ must keep passing and must not be modified.

## 2. Specification and contract
Feasible: True. Extend parse_duration to accept duration strings composed of one or more components (non-negative integer followed by unit d, h, m, s, ms) in descending order, each unit at most once, with optional whitespace around and between components, while preserving the existing plain-integer-seconds form. Return total seconds as float. Raise ValueError for malformed input and TypeError for non-string input.

| Name | Signature | Behavior | Errors |
| --- | --- | --- | --- |
| parse_duration | parse_duration(text: str) -> float | Parse a duration string and return the total number of seconds as a float. Accepted forms: 1. Plain non-negative integer (optional surrounding whitespace) inter | TypeError: if text is not a string; ValueError: if text is empty or whitespace-only; ValueError: if any number is negative; ValueError: if any number is fractio |

Acceptance criteria:
1. parse_duration('90') == 90.0 and surrounding whitespace is still ignored (existing behavior preserved).
2. Single components work for every unit: '2d' -> 172800.0, '3h' -> 10800.0, '15m' -> 900.0, '45s' -> 45.0, '500ms' -> 0.5.
3. Combined components in descending order work: '1h30m' -> 5400.0, '2d4h' -> 187200.0, '1m1s' -> 61.0, '1s500ms' -> 1.5, '1d1h1m1s1ms' -> 90061.001.
4. Whitespace is accepted around the string and between components: ' 1h 30m ' -> 5400.0; '1 h' raises ValueError.
5. '0s' and '0' return 0.0.
6. ValueError for: '', '   ', '-1h', '1.5h', '1x', '1h1h', '30m1h', 'h', '1h30', 'abc'.
7. TypeError for non-string input such as 90 or None.
8. The return type is float for every accepted input.

## 3. Sealed tests (written before implementation by an independent model instance)
`sealed/test_sealed.py` sha256 `9481f2f27668d776b1ff1b29bdf3235d61370c52be382a8d86c516214f5ff8ad`, 27 test methods, sealed at 2026-10-15T16:11:41.402309+00:00 by `nvidia/nemotron-3-super-120b-a12b`; attempts: 1.

Red check on the unmodified checkpoint (one child process per test under the supervisor): FAILED (14 of 27 methods: ERROR 13, FAIL 1): 14 of 27 methods failing, 13 passing; operation `01a14055-4df0-71a7-9baa-06bdb50aa2b0`.

| Sealed test method | Base (red) | Candidate |
| --- | --- | --- |
| test_sealed.TestParseDurationSealed.test_duplicate_unit_raises | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_empty_string_raises | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_five_components_all_units | ERROR (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_fractional_number_raises | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_negative_number_raises | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_non_string_input_raises_typeerror | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_number_without_unit_in_multi_component_raises | FAIL (1 ev) | FAIL (1 ev) |
| test_sealed.TestParseDurationSealed.test_plain_integer_seconds_preserved | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_plain_integer_with_surrounding_whitespace | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_return_type_is_float_for_combined | ERROR (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_return_type_is_float_for_plain_integer | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_return_type_is_float_for_single_component | ERROR (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_single_component_days | ERROR (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_single_component_hours | ERROR (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_single_component_milliseconds | ERROR (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_single_component_minutes | ERROR (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_single_component_seconds | ERROR (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_three_components_descending_order | ERROR (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_two_components_descending_order | ERROR (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_unit_without_preceding_number_raises | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_units_out_of_order_raises | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_unknown_unit_raises | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_whitespace_around_string_allowed | ERROR (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_whitespace_between_components_allowed | ERROR (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_whitespace_only_string_raises | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_zero_plain_integer | ok (1 ev) | ok (1 ev) |
| test_sealed.TestParseDurationSealed.test_zero_with_unit_seconds | ERROR (1 ev) | ok (1 ev) |

## 4. Candidate patch
1 changed path(s); scope check passed; 14 implementer turn(s).

```diff
--- a/durationkit/parse.py
+++ b/durationkit/parse.py
@@ -2,14 +2,75 @@
 
 
 def parse_duration(text: str) -> float:
-    """Parse a duration string and return the number of seconds as a float.
+    """Parse a duration string and return the total number of seconds as a float.
 
-    Only a plain non-negative integer number of seconds is accepted at the
-    moment, for example ``"90"``. Surrounding whitespace is ignored.
+    Accepted forms:
+    1. Plain non-negative integer (optional surrounding whitespace) interpreted as seconds.
+    2. One or more components: a non-negative integer immediately followed by a unit suffix (d, h, m, s, ms). Components must appear in descending unit order (d > h > m > s > ms). Each unit may appear at most once. Whitespace is allowed at the start/end of the string and between components, but not between a number and its unit. The function sums each component converted to seconds (1d=86400, 1h=3600, 1m=60, 1s=1, 1ms=0.001) and returns the total as float.
     """
     if not isinstance(text, str):
         raise TypeError("duration must be a string")
     stripped = text.strip()
-    if not stripped.isdigit():
-        raise ValueError(f"unsupported duration: {text!r}")
-    return float(stripped)
+    if not stripped:
+        raise ValueError("duration string is empty or only whitespace")
+    # Plain integer form (no units)
+    if stripped.isdigit():
+        return float(stripped)
+    # Component form
+    i = 0
+    n = len(stripped)
+    total_seconds = 0.0
+    seen_units = set()
+    last_rank = None
+    unit_order = {'d': 4, 'h': 3, 'm': 2, 's': 1, 'ms': 0}
+    while i < n:
+        # Skip whitespace between components
+        while i < n and stripped[i].isspace():
+            i += 1
+        if i >= n:
+            break  # trailing whitespace (should not happen because stripped)
+        # Parse number
+        start = i
+        while i < n and stripped[i].isdigit():
+            i += 1
+        if start == i:
+            raise ValueError(f"missing number at position {start}")
+        num_str = stripped[start:i]
+        # Parse unit
+        if i >= n:
+            raise ValueError(f"missing unit after number {num_str}")
+        # Check for 'ms'
+        if stripped[i] == 'm':
+            if i + 1 < n and stripped[i+1] == 's':
+                unit = 'ms'
+                i += 2
+            else:
+                unit = 'm'
+                i += 1
+        else:
+            unit = stripped[i]
+            i += 1
+        if unit not in unit_order:
+            raise ValueError(f"unknown unit '{unit}'")
+        # Check duplicate
+        if unit in seen_units:
+            raise ValueError(f"unit '{unit}' used more than once")
+        # Check order
+        rank = unit_order[unit]
+        if last_rank is not None and rank >= last_rank:
+            raise ValueError(f"units not in descending order: '{unit}' after previous unit")
+        seen_units.add(unit)
+        last_rank = rank
+        # Convert number to seconds
+        value = int(num_str)
+        if unit == 'd':
+            total_seconds += value * 86400
+        elif unit == 'h':
+            total_seconds += value * 3600
+        elif unit == 'm':
+            total_seconds += value * 60
+        elif unit == 's':
+            total_seconds += value
+        elif unit == 'ms':
+            total_seconds += value * 0.001
+    return total_seconds
```

## 5. Fresh-branch verification (bound to the sealed suite)
Existing suite: OK (6 passed of 6). Sealed suite: FAILED (1 of 27 methods: FAIL 1). Operation `01a14057-316a-73c9-9ae5-e61dbe1b2387`, networking disabled, disposable branch from the checkpoint.

| Binding check | Result |
| --- | --- |
| result_file_present | pass |
| supervisor_completed | pass |
| nonce_matches | pass |
| sealed_file_unchanged_before | pass |
| sealed_file_unchanged_after | pass |
| no_discovery_error | pass |
| expected_test_ids_present | pass |
| no_unexpected_test_ids | pass |
| static_ids_match_red | pass |
| no_nonzero_exit | FAIL |
| no_signal | pass |
| no_timeout | pass |
| no_missing_or_forged_result | pass |
| all_expected_pass | FAIL |

Held-out suite: none configured.

## 6. Gates
| Gate | Result | Detail |
| --- | --- | --- |
| existing_suite | pass | OK |
| sealed_binding | FAIL | child process nonzero exit: test_number_without_unit_in_multi_component_raises exit 1 |
| mutation | FAIL | not run: verification did not pass |
| adversarial_tests | FAIL | not run: verification did not pass |
| drift_audit | pass | score 0.0 (aligned) |

## 7. Breaker pass
Mutation pass not run (verification did not pass).

(none)

Model-written adversarial tests: not run.



## 8. Drift audit
Score 0.000 (aligned; threshold 0.6). The final implementation correctly extends parse_duration to accept multi-component duration strings with units d, h, m, s, ms in descending order, while preserving the plain integer form. All acceptance criteria are satisfied and existing tests pass.

Scope narrowed: none  
Scope widened: none  
Unsupported claims: ERROR: '1h 30m' should have raised ValueError

## 9. Grounding
No grounding calls (specification named no external references).



## 10. Ledger
| Model | Role | Stage | Effort | In | Out | Cached | USD | Elapsed | Status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| nebius_tokenfactory:nvidia/Nemotron-3-Ultra-550b-a55b | spec | spec | default | 2727 | 2471 | 0 | 0.010140 | 7.1s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | seal | seal-1 | default | 2750 | 5902 | 0 | 0.006137 | 25.1s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | implement | implement-1 | default | 1597 | 92 | 0 | 0.000562 | 1.4s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | implement | implement-2 | default | 1799 | 130 | 0 | 0.000657 | 1.9s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | implement | implement-3 | default | 2006 | 3990 | 0 | 0.004193 | 16.9s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | implement | implement-4 | default | 2194 | 297 | 0 | 0.000926 | 2.3s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | implement | implement-5 | default | 2878 | 116 | 0 | 0.000968 | 1.6s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | implement | implement-6 | default | 2947 | 923 | 0 | 0.001715 | 4.5s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | implement | implement-7 | default | 3797 | 6347 | 0 | 0.006851 | 28.9s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | implement | implement-8 | default | 3996 | 164 | 0 | 0.001346 | 2.4s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | implement | implement-9 | default | 4261 | 176 | 0 | 0.001437 | 2.0s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | implement | implement-10 | default | 4896 | 1392 | 0 | 0.002722 | 6.6s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | implement | implement-11 | default | 5626 | 249 | 0 | 0.001912 | 6.8s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | implement | implement-12 | default | 6284 | 2684 | 0 | 0.004301 | 14.3s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | implement | implement-13 | default | 5721 | 330 | 0 | 0.002013 | 2.5s | ok |
| nebius_tokenfactory:nvidia/nemotron-3-super-120b-a12b | implement | implement-14 | default | 6298 | 759 | 0 | 0.002573 | 5.4s | ok |
| nebius_tokenfactory:nvidia/Nemotron-3-Ultra-550b-a55b | audit | drift-audit | default | 3247 | 2645 | 0 | 0.011182 | 8.0s | ok |

Model calls: 17 (0 failed, 0 malformed); tokens in/out/cached 63024/28667/0; USD: 0.059635.

| Sandbox op | Operation | Status | Exit | Duration | Image | Net | raw cost diag (not USD) |
| --- | --- | --- | --- | --- | --- | --- | --- |
| checkpoint | 01a14054-c27f-7559-98d5-5b79fc232af3 | SUCCESS | 0 | 0.833s | retained | off | 0.00276453 |
| red-1 | 01a14055-4df0-71a7-9baa-06bdb50aa2b0 | SUCCESS | 0 | 5.506s | disposable | off | 0.0458813 |
| impl-tests-5 | 01a14055-c832-7602-96a6-1d7b97d8f2e1 | SUCCESS | 0 | 0.82s | disposable | off | 0.00275671 |
| impl-python-6 | 01a14055-e681-7177-85f3-bd7f1aea3cb1 | SUCCESS | 0 | 0.658s | disposable | off | 0.0016132199999999998 |
| impl-tests-8 | 01a14056-6d95-752e-a213-36a0305ecc81 | SUCCESS | 0 | 0.82s | disposable | off | 0.00282496 |
| impl-python-10 | 01a14056-9b50-72a0-a896-832499e52238 | SUCCESS | 0 | 0.646s | disposable | off | 0.00114011 |
| impl-tests-12 | 01a14056-f441-7294-bb0b-ae3e6f512c71 | SUCCESS | 0 | 0.806s | disposable | off | 0.00276456 |
| impl-python-14 | 01a14057-2111-7072-9d87-d0137bf156db | SUCCESS | 0 | 0.674s | disposable | off | 0.00113887 |
| verify | 01a14057-316a-73c9-9ae5-e61dbe1b2387 | SUCCESS | 0 | 5.539s | disposable | off | 0.04709497000000001 |

Sandbox operations: 9, total guest duration 16.302s, retained images ['8fe2cd71-f45a-475a-bbea-53544d076ff4'].

## 11. Limitations of this bundle
- Profile 'judge-demo': inference provider nebius_tokenfactory; submission runs must use NVIDIA Nemotron on Nebius Token Factory and are labeled separately.
- Sealed and adversarial suites run one child process per test under a supervisor that never imports candidate code; a candidate can still tamper from inside a child after the nonce was read (the mutation gate and held-out tests are the structural detectors).
- Model-written adversarial tests can be wrong; their failures block VERIFIED and are listed for a human, not arbitrated automatically.
- Grounding runs only when the specification names external references; sources are cited, not verified for correctness.
- Sandbox CPU/RAM quota controls were not found in the current public REST API; per operation only max_layer_bytes, a timeout and the networking flag are set.
- Sandbox raw 'cost' diagnostics are not USD; Codex gateway usage is ChatGPT allowance, not a Nebius charge; Nebius USD is computed from the public price table, not an invoice.
- Each run retains one checkpoint image on the service; no image-delete control was found in the current public REST API.
