import unittest
from durationkit import parse_duration

class TestParseDurationSealed(unittest.TestCase):
    def test_plain_integer_seconds_preserved(self):
        self.assertEqual(parse_duration('90'), 90.0)

    def test_plain_integer_with_surrounding_whitespace(self):
        self.assertEqual(parse_duration('  42 '), 42.0)

    def test_zero_plain_integer(self):
        self.assertEqual(parse_duration('0'), 0.0)

    def test_zero_with_unit_seconds(self):
        self.assertEqual(parse_duration('0s'), 0.0)

    def test_single_component_days(self):
        self.assertEqual(parse_duration('2d'), 2 * 86400.0)

    def test_single_component_hours(self):
        self.assertEqual(parse_duration('3h'), 3 * 3600.0)

    def test_single_component_minutes(self):
        self.assertEqual(parse_duration('15m'), 15 * 60.0)

    def test_single_component_seconds(self):
        self.assertEqual(parse_duration('45s'), 45.0)

    def test_single_component_milliseconds(self):
        self.assertAlmostEqual(parse_duration('500ms'), 0.5)

    def test_two_components_descending_order(self):
        self.assertEqual(parse_duration('1h30m'), 1*3600 + 30*60)

    def test_three_components_descending_order(self):
        self.assertEqual(parse_duration('2d4h'), 2*86400 + 4*3600)

    def test_five_components_all_units(self):
        expected = 1*86400 + 1*3600 + 1*60 + 1*1 + 1*0.001
        self.assertAlmostEqual(parse_duration('1d1h1m1s1ms'), expected)

    def test_whitespace_between_components_allowed(self):
        self.assertEqual(parse_duration(' 1h 30m '), 1*3600 + 30*60)

    def test_whitespace_around_string_allowed(self):
        self.assertEqual(parse_duration('   2d   '), 2*86400.0)

    def test_number_without_unit_in_multi_component_raises(self):
        with self.assertRaises(ValueError) as cm:
            parse_duration('1h30')
        self.assertIn('number without unit', str(cm.exception).lower())

    def test_unit_without_preceding_number_raises(self):
        with self.assertRaises(ValueError):
            parse_duration('h')

    def test_unknown_unit_raises(self):
        with self.assertRaises(ValueError):
            parse_duration('1x')

    def test_duplicate_unit_raises(self):
        with self.assertRaises(ValueError):
            parse_duration('1h1h')

    def test_units_out_of_order_raises(self):
        with self.assertRaises(ValueError):
            parse_duration('30m1h')

    def test_negative_number_raises(self):
        with self.assertRaises(ValueError):
            parse_duration('-1h')

    def test_fractional_number_raises(self):
        with self.assertRaises(ValueError):
            parse_duration('1.5h')

    def test_empty_string_raises(self):
        with self.assertRaises(ValueError):
            parse_duration('')

    def test_whitespace_only_string_raises(self):
        with self.assertRaises(ValueError):
            parse_duration('   ')

    def test_non_string_input_raises_typeerror(self):
        with self.assertRaises(TypeError):
            parse_duration(90)

    def test_return_type_is_float_for_plain_integer(self):
        self.assertIsInstance(parse_duration('7'), float)

    def test_return_type_is_float_for_single_component(self):
        self.assertIsInstance(parse_duration('2d'), float)

    def test_return_type_is_float_for_combined(self):
        self.assertIsInstance(parse_duration('1h30m'), float)